import { SWAGGER_URL } from '@common/variables/environment';

export const swaggerOption = {
  serverUrl: SWAGGER_URL,
};
